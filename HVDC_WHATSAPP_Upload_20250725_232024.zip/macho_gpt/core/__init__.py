"""
MACHO-GPT Core 모듈
-----------------
WhatsApp 메시지 처리 및 분석 핵심 기능
"""

from .logi_whatsapp_241219 import WhatsAppProcessor, WhatsAppMessage

__all__ = ["WhatsAppProcessor", "WhatsAppMessage"] 