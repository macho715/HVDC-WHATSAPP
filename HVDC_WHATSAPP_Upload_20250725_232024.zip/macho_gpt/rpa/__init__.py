"""
MACHO-GPT RPA 모듈
-----------------
Playwright 기반 WhatsApp Web 자동화 기능
"""

from .logi_rpa_whatsapp_241219 import WhatsAppRPAExtractor

__all__ = ["WhatsAppRPAExtractor"] 