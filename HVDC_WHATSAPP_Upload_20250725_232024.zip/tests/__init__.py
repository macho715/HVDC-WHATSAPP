"""
MACHO-GPT 테스트 모듈
-------------------
TDD 방식으로 작성된 테스트 케이스들

테스트 실행:
$ pytest tests/
$ python -m pytest tests/test_whatsapp_processor.py
"""

__version__ = "1.0"
__description__ = "WhatsApp 업무 요약 시스템 테스트" 